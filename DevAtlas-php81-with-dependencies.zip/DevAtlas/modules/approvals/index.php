<?php
/**
 * Filename: index.php
 * Purpose: Forward the approval workspace to CodeIgniter.
 * Developer: DevAtlas maintainers
 * Date: 2026-10-29
 * Recent updates: Integrate CodeIgniter with preserved DevAtlas security contracts.
 */

require __DIR__ . '/../../public/index.php';
