<?php

/**
 * Filename: DailyLogTree.php
 * Purpose: Read a complete employee week for the Team Monitoring activity tree.
 * Developer: DevAtlas maintainers
 * Date: 2026-11-06
 * Recent updates: Reuse monitoring scope and exclude private drafts from the overview.
 */

use CodeIgniter\Database\BaseConnection;

require_once __DIR__.'/DailyLogs.php';

final class DailyLogTree
{
    public static function MemberWeek(BaseConnection $db, int $actor, array $data): array
    {
        [$where,$params] = DailyLogs::Scope($db, $actor, 0, false, true);
        $user = filter_var($data['user_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($user === false)
        {
            throw new InvalidArgumentException('Choose a team member.');
        }
        [$start,$end] = DailyLogCalendar::Week(DailyLogs::Date($data['week_start'] ?? null));
        $sql = "SELECT u.user_id,u.employee_id,CONCAT_WS(' ',u.first_name,u.middle_name,u.last_name) employee_name,un.unit_name
            FROM users u LEFT JOIN org_units un ON un.unit_id=u.unit_id WHERE u.user_id=? AND u.is_active".$where;
        $employee = $db->query($sql, array_merge([$user], $params))->getUnbufferedRow('array');
        if (!$employee)
        {
            throw new OutOfBoundsException('Employee not found in your monitoring scope.');
        }
        $sql = "SELECT l.log_id,l.activity_date,l.entry_kind,l.classification,l.activity_type,l.planned_task,l.actual_activity,
            l.duration_hours,l.status,l.remarks,l.review_comment FROM daily_logs l JOIN users u ON u.user_id=l.user_id
            LEFT JOIN org_units un ON un.unit_id=u.unit_id WHERE u.user_id=? AND u.is_active
            AND l.activity_date BETWEEN ? AND ? AND l.entry_kind='activity' AND l.status IN('Submitted','Reviewed','Returned')".$where.
            ' ORDER BY l.activity_date DESC,l.log_id ASC';
        $logs = $db->query($sql, array_merge([$user,$start,$end], $params))->getResultArray();
        return ['employee' => $employee,'week_start' => $start,'week_end' => $end,'logs' => $logs,
            'hours' => round(array_sum(array_column($logs, 'duration_hours')), 2)];
    }
}
