/**
 * Filename: leaves.js
 * Purpose: Render department leave calendars, personal applications and section approvals.
 * Developer: DevAtlas maintainers
 * Date: 2026-10-28
 * Recent updates: Keep the month and day-panel calendar and add selection-based atomic leave approvals.
 */
(() =>
{
    'use strict';
    const ROOT = document.getElementById('leavesApp') || document.getElementById('leaveApprovalsApp');
    if (!ROOT)
    {
        return;
    }
    const IS_APPROVALS = ROOT.id === 'leaveApprovalsApp';
    const PREVIEW_LIMIT = 2;
    const GetElement = id => document.getElementById(id);
    const ESC = AT.escapeHtml;
    const STATE =
    {
        data: null,
        editing: null,
        detail: null,
        minePage: 1,
        reviewPage: 1,
        isBusy: false,
        request: 0,
        day: null,
        dayTab: 'leave',
        calendarMonth: null,
        events: new Map(),
        selected: new Set(),
        isLoading: false
    };
    const INITIAL = new URLSearchParams(location.search);
    const TODAY = new Intl.DateTimeFormat('en-CA',
    {
        timeZone: 'Asia/Manila', year: 'numeric', month: '2-digit', day: '2-digit'
    }).format(new Date());
    const Api = (action, body = null, query =
    {
    }) => AT.api(ROOT.dataset.api + '?' + new URLSearchParams(
    {
        action, ...query
    }), body ?
    {
        method: 'POST', body
    }
    :
    {
    });
    const Hours = value => Number(value || 0).toFixed(2);
    const Label = row => row.leave_type === 'UT' ? 'UT · Undertime' : `${row.leave_type || '—'} · ${{ AM: 'AM', PM: 'PM', WHOLE: 'Whole day' }[row.leave_period] || 'Not selected'}`;
    const Status = status => status === 'Reviewed' ? 'Approved' : status === 'Submitted' ? 'Pending approval' : status;
    const Badge = status => `<span class="ws-tag ${status === 'Reviewed' ? 'green' : status === 'Submitted' ? 'amber' : status === 'Returned' ? 'red' : 'gray'}">${ESC(Status(status))}</span>`;
    function ErrorAt(id, message = '')
    {
        GetElement(id).textContent = message;
        GetElement(id).toggleAttribute('hidden', !message);
        if (message)
        {
            GetElement(id).focus();
        }
    }
    function Busy(isBusy)
    {
        STATE.isBusy = isBusy;
        for (const ID of ['leaveSaveDraft', 'leaveSubmit', 'leaveApprove', 'leaveReturn', 'leaveDelete'])
        {
            if (GetElement(ID))
            {
                GetElement(ID).disabled = isBusy;
            }
        }
        UpdateBatchControls();
    }
    function DateLabel(date)
    {
        return new Date(date + 'T12:00:00').toLocaleDateString('en-PH',
        {
            weekday: 'long', month: 'long', day: 'numeric', year: 'numeric'
        });
    }
    function DayEvents(data, date)
    {
        return STATE.events.get(date) || [];
    }
    function TypeName(code)
    {
        const OPTION = [...(GetElement('leaveType')?.options || [])].find(option => option.value === code);
        return OPTION ? OPTION.textContent.replace(/^[A-Z0-9_]+\s*[—–-]\s*/, '').trim() : code;
    }
    function TypeClass(code)
    {
        return ['VL', 'SL', 'ML', 'EL', 'UT', 'BL'].includes(code) ? 'leave-type-' + code.toLowerCase() : 'leave-type-other';
    }
    function Initials(name)
    {
        const PARTS = name.trim().split(/\s+/);
        return (PARTS[0][0] + (PARTS.length > 1 ? PARTS[PARTS.length - 1][0] : '')).toUpperCase();
    }
    function EventCard(event)
    {
        const ROW = event.row;
        if (event.kind === 'birthday')
        {
            return `<div class="leave-birthday"><span class="leave-event-avatar">${AT.icon('calendar-days')}</span><div class="leave-event-content"><strong>${ESC(ROW.employee_name)}</strong><small>Birthday</small><span class="leave-birthday-note">Celebrating today</span></div></div>`;
        }
        const TITLE = `${ROW.employee_name} · ${Label(ROW)} · ${Hours(ROW.duration_hours)} hours · ${Status(ROW.status)}`;
        return `<button type="button" class="leave-event ${ROW.status === 'Reviewed' ? 'is-approved' : ''}" data-leave-view="${ESC(ROW.log_id)}" aria-label="${ESC(TITLE)}"><span class="leave-event-avatar">${ESC(Initials(ROW.employee_name || '?'))}</span><span class="leave-event-content"><strong>${ESC(ROW.employee_name)}</strong>${ROW.unit_name ? `<small>${ESC(ROW.unit_name)}</small>` : ''}<span class="leave-event-meta"><span class="leave-type-tag ${TypeClass(ROW.leave_type)}" title="${ESC(TypeName(ROW.leave_type))}">${ESC(ROW.leave_type)}</span><span>${ESC({ AM: 'AM', PM: 'PM', WHOLE: 'Whole day' }[ROW.leave_period] || 'Undertime')} · ${Number(ROW.duration_hours)}h</span></span><span class="leave-event-status">${Badge(ROW.status)}</span></span><span class="leave-event-arrow">${AT.icon('chevron-right')}</span></button>`;
    }
    function Preview(event, date)
    {
        const ROW = event.row;
        const IS_BIRTHDAY = event.kind === 'birthday';
        const LABEL = ROW.employee_name + (IS_BIRTHDAY ? ' · Birthday' : ' · ' + Label(ROW) + ' · ' + Status(ROW.status));
        return `<button type="button" tabindex="-1" class="leave-chip ${IS_BIRTHDAY ? 'leave-chip-birthday' : TypeClass(ROW.leave_type)} ${ROW.status === 'Reviewed' ? 'is-approved' : ''}" data-leave-day="${date}" title="${ESC(LABEL)}" aria-label="${ESC(LABEL)}. Show selected day.">${IS_BIRTHDAY ? AT.icon('calendar-days') : '<span class="leave-chip-status" aria-hidden="true"></span>'}<span>${ESC(ROW.employee_name)}</span>${IS_BIRTHDAY ? '' : `<b>${ESC(ROW.leave_type)}</b>`}</button>`;
    }
    function SetupCalendar()
    {
        if (IS_APPROVALS)
        {
            return;
        }
        const CALENDAR = GetElement('leaveCalendar');
        const CARD = CALENDAR.closest('.ws-card');
        const HEADING = CARD.querySelector('.ws-card-heading');
        const FILTERS = GetElement('leaveFilters');
        ROOT.dataset.leavesUi = 'concept-1';
        CARD.classList.add('leave-calendar-card');
        HEADING.classList.add('leave-month-heading');
        CARD.insertBefore(HEADING, FILTERS);
        HEADING.insertBefore(FILTERS, HEADING.lastElementChild);
        const DESCRIPTION = ROOT.querySelector('.ws-hero p');
        if (DESCRIPTION)
        {
            DESCRIPTION.textContent = 'Department leave planning and birthdays. Select a date to see the full day.';
        }
        FILTERS.classList.add('leave-calendar-filters');
        const SUMMARY = document.createElement('section');
        SUMMARY.className = 'leave-summary';
        SUMMARY.setAttribute('aria-label', 'Leave calendar overview');
        SUMMARY.innerHTML = `<div class="leave-summary-item"><span class="leave-summary-icon">${AT.icon('users')}</span><div><span class="leave-summary-label">On leave</span><strong id="leaveSummaryOn">—</strong><small id="leaveSummaryDate">Selected day</small></div></div><div class="leave-summary-item"><span class="leave-summary-icon is-pending">${AT.icon('clipboard-check')}</span><div><span class="leave-summary-label">Pending leave days</span><strong id="leaveSummaryPending">—</strong><small class="leave-summary-month">Selected month</small></div></div><div class="leave-summary-item"><span class="leave-summary-icon is-birthday">${AT.icon('calendar-days')}</span><div><span class="leave-summary-label">Birthdays</span><strong id="leaveSummaryBirthdays">—</strong><small class="leave-summary-month">Selected month</small></div></div>`;
        ROOT.insertBefore(SUMMARY, CARD);
        const LAYOUT = document.createElement('div');
        LAYOUT.className = 'leave-calendar-layout';
        const MONTH = document.createElement('div');
        MONTH.className = 'leave-calendar-month';
        MONTH.append(CARD.querySelector('.leave-legend'), CARD.querySelector('.leave-calendar-scroll'), GetElement('leaveCalendarCount'));
        const PANEL = document.createElement('aside');
        PANEL.id = 'leaveDayPanel';
        PANEL.className = 'leave-day-panel';
        PANEL.setAttribute('aria-labelledby', 'leaveDayTitle');
        PANEL.innerHTML = `<div class="leave-day-heading"><span class="leave-panel-eyebrow">SELECTED DAY</span><h3 id="leaveDayTitle" tabindex="-1"></h3><p id="leaveDaySummary" role="status" aria-live="polite"></p><p id="leaveDayHoliday" class="leave-day-holiday" hidden></p></div><div class="leave-day-tabs" role="tablist" aria-label="Selected day events"><button type="button" role="tab" id="leaveDayLeaveTab" data-leave-tab="leave" aria-selected="true" aria-controls="leaveDayLeavePanel">Leave <span id="leaveDayLeaveCount">0</span></button><button type="button" role="tab" id="leaveDayBirthdayTab" data-leave-tab="birthday" aria-selected="false" aria-controls="leaveDayBirthdayPanel" tabindex="-1">Birthdays <span id="leaveDayBirthdayCount">0</span></button></div><div class="leave-day-content"><div id="leaveDayLeavePanel" role="tabpanel" aria-labelledby="leaveDayLeaveTab" tabindex="0"><div id="leaveDayEvents" class="leave-day-events"></div></div><div id="leaveDayBirthdayPanel" role="tabpanel" aria-labelledby="leaveDayBirthdayTab" tabindex="0" hidden><div id="leaveDayBirthdays" class="leave-day-events"></div></div></div><div class="leave-day-footer"><button type="button" class="btn btn-primary" id="leaveDayApply" hidden>${AT.icon('plus')} Apply for this day</button><p>Leave remarks are visible only to you and your authorized section approvers.</p></div>`;
        LAYOUT.append(MONTH, PANEL);
        CARD.append(LAYOUT);
    }
    function SetDayTab(kind, focus = false)
    {
        if (STATE.dayTab !== kind)
        {
            ROOT.querySelector('.leave-day-content').scrollTop = 0;
        }
        STATE.dayTab = kind;
        for (const [KIND, ID] of [['leave', 'Leave'], ['birthday', 'Birthday']])
        {
            const TAB = GetElement('leaveDay' + ID + 'Tab');
            const SELECTED = kind === KIND;
            TAB.setAttribute('aria-selected', String(SELECTED));
            TAB.tabIndex = SELECTED ? 0 : -1;
            GetElement('leaveDay' + ID + 'Panel').hidden = !SELECTED;
            if (SELECTED && focus)
            {
                TAB.focus();
            }
        }
    }
    function UpdateSelection()
    {
        for (const CELL of GetElement('leaveCalendar').querySelectorAll('.leave-calendar-day'))
        {
            const BUTTON = CELL.querySelector('.leave-calendar-select');
            const SELECTED = BUTTON.dataset.leaveDay === STATE.day;
            CELL.classList.toggle('is-selected', SELECTED);
            BUTTON.setAttribute('aria-pressed', String(SELECTED));
            BUTTON.tabIndex = SELECTED ? 0 : -1;
        }
        const LEAVES = DayEvents(STATE.data, STATE.day).filter(event => event.kind === 'leave');
        GetElement('leaveSummaryOn').textContent = new Set(LEAVES.map(event => event.row.user_id)).size;
        GetElement('leaveSummaryDate').textContent = new Date(STATE.day + 'T12:00:00').toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' });
    }
    function RenderDay(date)
    {
        const DATA = STATE.data;
        const EVENTS = DayEvents(DATA, date);
        const LEAVES = EVENTS.filter(event => event.kind === 'leave');
        const BIRTHDAYS = EVENTS.filter(event => event.kind === 'birthday');
        const IS_WEEKEND = [0, 6].includes(new Date(date + 'T12:00:00').getDay());
        const HOLIDAY = DATA.holidays[date]?.holiday_name;
        GetElement('leaveDayTitle').textContent = new Date(date + 'T12:00:00').toLocaleDateString('en-PH', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
        GetElement('leaveDaySummary').textContent = EVENTS.length + (EVENTS.length === 1 ? ' event' : ' events') + (IS_WEEKEND ? ' · Non-working weekend' : '');
        GetElement('leaveDayLeaveCount').textContent = LEAVES.length;
        GetElement('leaveDayBirthdayCount').textContent = BIRTHDAYS.length;
        GetElement('leaveDayHoliday').hidden = !HOLIDAY;
        GetElement('leaveDayHoliday').textContent = HOLIDAY || '';
        GetElement('leaveDayEvents').innerHTML = LEAVES.length ? LEAVES.map(EventCard).join('') : '<div class="leave-day-empty">' + AT.icon('calendar-days') + '<strong>No leave entries</strong><p>No submitted or approved leave for this date.</p></div>';
        GetElement('leaveDayBirthdays').innerHTML = BIRTHDAYS.length ? BIRTHDAYS.map(EventCard).join('') : '<div class="leave-day-empty">' + AT.icon('calendar-days') + '<strong>No birthdays</strong><p>No birthdays listed for this date.</p></div>';
        GetElement('leaveDayApply').hidden = ROOT.dataset.create !== '1' || IS_WEEKEND || !!HOLIDAY || date < '1900-01-01' || date > '2100-12-31';
        SetDayTab(STATE.dayTab);
        UpdateSelection();
    }
    function OpenDay(date, reveal = false)
    {
        if (!STATE.data || !/^\d{4}-\d{2}-\d{2}$/.test(date) || date < STATE.data.from || date > STATE.data.to)
        {
            return;
        }
        STATE.day = date;
        const EVENTS = DayEvents(STATE.data, date);
        STATE.dayTab = EVENTS.length && EVENTS.every(event => event.kind === 'birthday') ? 'birthday' : 'leave';
        RenderDay(date);
        ROOT.querySelector('.leave-day-content').scrollTop = 0;
        if (reveal && GetElement('leaveDayPanel').getBoundingClientRect().top > innerHeight - 120)
        {
            GetElement('leaveDayTitle').focus({ preventScroll: true });
            GetElement('leaveDayPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    function RenderLegend(data)
    {
        const TYPES = [...new Set([...(GetElement('leaveType')?.options || [])].map(option => option.value).concat(data.leaves.map(row => row.leave_type)))].filter(Boolean);
        ROOT.querySelector('.leave-legend').innerHTML = '<span class="leave-legend-label">Leave types</span>' + TYPES.map(code => `<span class="leave-legend-item" title="${ESC(TypeName(code))}"><span class="leave-type-tag ${TypeClass(code)}">${ESC(code)}</span><span>${ESC(TypeName(code).replace(/ Leave$/i, ''))}</span></span>`).join('') + `<span class="leave-legend-item leave-legend-birthday">${AT.icon('calendar-days')} Birthday</span><span class="leave-legend-status"><span class="leave-status-dot is-approved"></span> Approved <span class="leave-status-dot"></span> Pending</span>`;
    }
    function RenderCalendar(data)
    {
        STATE.events = new Map();
        for (const ROW of data.leaves)
        {
            if (!STATE.events.has(ROW.activity_date))
            {
                STATE.events.set(ROW.activity_date, []);
            }
            STATE.events.get(ROW.activity_date).push({ kind: 'leave', row: ROW });
        }
        for (const ROW of data.birthdays || [])
        {
            if (!STATE.events.has(ROW.date))
            {
                STATE.events.set(ROW.date, []);
            }
            STATE.events.get(ROW.date).push({ kind: 'birthday', row: ROW });
        }
        if (STATE.calendarMonth !== data.month || !STATE.day || STATE.day < data.from || STATE.day > data.to)
        {
            STATE.day = TODAY.startsWith(data.month) ? TODAY : data.month + '-01';
            STATE.dayTab = 'leave';
        }
        STATE.calendarMonth = data.month;
        const DAYS = [];
        for (let date = new Date(data.from + 'T12:00:00'); date <= new Date(data.to + 'T12:00:00'); date.setDate(date.getDate() + 1))
        {
            const KEY = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
            const HOLIDAY = data.holidays[KEY]?.holiday_name;
            const WEEKDAY = date.getDay();
            const IS_WEEKEND = WEEKDAY === 0 || WEEKDAY === 6;
            const EVENTS = DayEvents(data, KEY);
            const MORE = Math.max(0, EVENTS.length - PREVIEW_LIMIT);
            const WEEKEND_CLASS = WEEKDAY === 0 ? 'is-sunday' : WEEKDAY === 6 ? 'is-saturday' : '';
            const TITLE = DateLabel(KEY) + ', ' + EVENTS.length + (EVENTS.length === 1 ? ' event' : ' events') + (IS_WEEKEND ? ', non-working weekend' : '') + (HOLIDAY ? ', ' + HOLIDAY : '');
            DAYS.push(`<div role="cell" class="leave-calendar-day ${WEEKEND_CLASS} ${KEY.startsWith(data.month) ? '' : 'is-outside'} ${KEY === TODAY ? 'is-today' : ''}"><button type="button" class="leave-calendar-select" data-leave-day="${KEY}" aria-controls="leaveDayPanel" aria-pressed="${KEY === STATE.day}" tabindex="${KEY === STATE.day ? 0 : -1}" aria-label="${ESC(TITLE)}"><time datetime="${KEY}" ${KEY === TODAY ? 'aria-current="date"' : ''}>${date.getDate()}</time></button>${HOLIDAY ? `<div class="leave-calendar-holiday" title="${ESC(HOLIDAY)}">${ESC(HOLIDAY)}</div>` : ''}<div class="leave-calendar-events">${EVENTS.slice(0, PREVIEW_LIMIT).map(event => Preview(event, KEY)).join('')}</div>${MORE ? `<button type="button" tabindex="-1" class="leave-calendar-more" data-leave-day="${KEY}" data-leave-reveal="1" aria-controls="leaveDayPanel" aria-label="Show all ${EVENTS.length} events for ${ESC(DateLabel(KEY))}">+${MORE} more</button>` : ''}</div>`);
        }
        let html = '<div role="row" class="leave-calendar-row leave-calendar-head">' + ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => `<div role="columnheader" class="${index === 0 ? 'is-sunday' : index === 6 ? 'is-saturday' : ''}">${day}${index === 0 || index === 6 ? '<small>Non-working</small>' : ''}</div>`).join('') + '</div>';
        for (let index = 0; index < DAYS.length; index += 7)
        {
            html += '<div role="row" class="leave-calendar-row">' + DAYS.slice(index, index + 7).join('') + '</div>';
        }
        GetElement('leaveCalendar').innerHTML = html;
        GetElement('leaveCalendar').setAttribute('aria-busy', 'false');
        const MONTH = new Date(data.month + '-01T12:00:00').toLocaleDateString('en-PH', { month: 'long', year: 'numeric' });
        GetElement('leaveCalendarTitle').textContent = MONTH;
        const DEPARTMENT = data.departments.find(row => Number(row.department_id) === Number(data.department_id))?.department_name || data.profile.department_name;
        GetElement('leaveScope').textContent = DEPARTMENT ? DEPARTMENT + ' · All sections' : 'Your own calendar. Assign your account to a department and section to share and submit leave.';
        GetElement('leaveCalendarCount').textContent = 'Select a date to see every leave entry and birthday. Use the arrow keys to move between dates.';
        const MONTH_LEAVES = data.leaves.filter(row => row.activity_date.startsWith(data.month));
        GetElement('leaveSummaryPending').textContent = MONTH_LEAVES.filter(row => row.status === 'Submitted').length;
        GetElement('leaveSummaryBirthdays').textContent = (data.birthdays || []).filter(row => row.date.startsWith(data.month)).length;
        for (const LABEL of ROOT.querySelectorAll('.leave-summary-month'))
        {
            LABEL.textContent = MONTH;
        }
        RenderLegend(data);
        RenderDay(STATE.day);
    }

    function UpdateBatchControls()
    {
        if (!IS_APPROVALS || !GetElement('leaveSelectAll'))
        {
            return;
        }
        const ROWS = STATE.data?.pending?.rows || [];
        const COUNT = STATE.selected.size;
        const DISABLED = STATE.isBusy || STATE.isLoading;
        const ALL = GetElement('leaveSelectAll');
        ALL.disabled = DISABLED || !ROWS.length;
        ALL.checked = ROWS.length > 0 && COUNT === ROWS.length;
        ALL.indeterminate = COUNT > 0 && COUNT < ROWS.length;
        for (const CHECK of ROOT.querySelectorAll('[data-leave-select]'))
        {
            CHECK.checked = STATE.selected.has(CHECK.dataset.leaveSelect);
            CHECK.disabled = DISABLED;
            CHECK.closest('tr').classList.toggle('is-leave-selected', CHECK.checked);
        }
        for (const BUTTON of ROOT.querySelectorAll('[data-leave-view]'))
        {
            BUTTON.disabled = DISABLED;
        }
        GetElement('leaveBatchCount').textContent = COUNT + ' selected · Select all applies to this page only.';
        GetElement('leaveBatchApprove').disabled = DISABLED || !COUNT;
        GetElement('leaveBatchApprove').textContent = COUNT ? 'Approve selected (' + COUNT + ')' : 'Approve selected';
        GetElement('leaveBatchClear').disabled = DISABLED || !COUNT;
        GetElement('leaveRefresh').disabled = DISABLED;
        GetElement('leaveReviewPrevious').disabled = DISABLED || !STATE.data || STATE.data.pending.page <= 1;
        GetElement('leaveReviewNext').disabled = DISABLED || !STATE.data || STATE.data.pending.page >= STATE.data.pending.pages;
    }
    async function ApproveBatch()
    {
        if (STATE.isBusy || STATE.isLoading || !STATE.selected.size)
        {
            return;
        }
        const ROWS = STATE.data.pending.rows.filter(row => STATE.selected.has(String(row.log_id)));
        const REQUESTS = ROWS.map(row => ({ log_id: Number(row.log_id), version: Number(row.version) }));
        Busy(true);
        ErrorAt('leaveError');
        try
        {
            const PEOPLE = new Set(ROWS.map(row => row.user_id)).size;
            const SUMMARY = REQUESTS.length + ' leave applications for ' + PEOPLE + (PEOPLE === 1 ? ' employee. ' : ' employees. ') + 'Every working day in each selected application will be approved.';
            if (!await AT.confirmAction(SUMMARY, 'Approve selected leave?', 'Approve ' + REQUESTS.length + (REQUESTS.length === 1 ? ' application' : ' applications')))
            {
                return;
            }
            const RESULT = await Api('approve_leaves', { requests: REQUESTS });
            STATE.selected.clear();
            AT.toast(RESULT.approved + (RESULT.approved === 1 ? ' leave application approved.' : ' leave applications approved.'));
            await Load();
        }
        catch (error)
        {
            await Load();
            ErrorAt('leaveError', error.message);
        }
        finally
        {
            Busy(false);
        }
    }

    function RenderList(prefix, data, isReview = false)
    {
        const BODY = GetElement(prefix + 'Rows');
        if (!BODY)
        {
            return;
        }
        BODY.innerHTML = data.rows.length ? data.rows.map(row => `<tr>${isReview ? `<td class="leave-selection-cell"><input type="checkbox" data-leave-select="${ESC(row.log_id)}" aria-label="Select leave for ${ESC(row.employee_name)}, ${ESC(row.date_from)} to ${ESC(row.date_to)}"></td><td>${ESC(row.employee_name)}</td>` : ''}<td>${ESC(row.date_from)}${row.date_to !== row.date_from ? '<small>to ' + ESC(row.date_to) + '</small>' : ''}</td><td>${ESC(Label(row))}</td><td>${Hours(row.duration_hours)}</td>${isReview ? '' : `<td>${Badge(row.status)}</td>`}<td><button type="button" class="btn btn-sm" data-leave-view="${row.log_id}">${isReview ? 'Review' : 'View'}</button></td></tr>`).join('') : `<tr><td colspan="${isReview ? 6 : 5}"><div class="ws-state">${isReview ? 'No pending requests in your section.' : 'No leave applications for this month.'}</div></td></tr>`;
        GetElement(prefix + 'Count').textContent = `${data.total} requests · Page ${data.page} of ${data.pages}`;
        GetElement(prefix + 'Previous').toggleAttribute('disabled', data.page <= 1);
        GetElement(prefix + 'Next').toggleAttribute('disabled', data.page >= data.pages);
        if (isReview)
        {
            UpdateBatchControls();
        }
    }
    async function Load()
    {
        const REQUEST = ++STATE.request;
        STATE.isLoading = true;
        STATE.selected.clear();
        UpdateBatchControls();
        ErrorAt('leaveError');
        GetElement('leaveCalendar')?.setAttribute('aria-busy', 'true');
        try
        {
            const QUERY =
            {
                month: GetElement('leaveMonth')?.value || TODAY.slice(0, 7), 'mine_page': STATE.minePage, 'review_page': STATE.reviewPage
            };
            if (GetElement('leaveDepartment')?.value)
            {
                QUERY['department_id'] = GetElement('leaveDepartment').value;
            }
            const DATA = await Api('calendar', null, QUERY);
            if (REQUEST !== STATE.request)
            {
                return;
            }
            STATE.data = DATA;
            STATE.minePage = DATA.mine.page;
            STATE.reviewPage = DATA.pending.page;
            if (GetElement('leaveDepartment'))
            {
                GetElement('leaveDepartment').replaceChildren(new Option('My calendar', ''), ...DATA.departments.map(row => new Option(row.department_name, row.department_id)));
                GetElement('leaveDepartment').value = DATA.department_id || '';
            }
            if (!IS_APPROVALS)
            {
                RenderCalendar(DATA);
                RenderList('leaveMine', DATA.mine);
            }
            RenderList('leaveReview', DATA.pending, true);
        }
        catch (error)
        {
            if (REQUEST === STATE.request)
            {
                ErrorAt('leaveError', error.message);
                GetElement('leaveCalendar')?.setAttribute('aria-busy', 'false');
            }
        }
        finally
        {
            if (REQUEST === STATE.request)
            {
                STATE.isLoading = false;
                UpdateBatchControls();
            }
        }
    }
    function SyncType()
    {
        const IS_UT = GetElement('leaveType').value === 'UT';
        GetElement('leavePeriodRow').hidden = IS_UT;
        GetElement('leavePeriod').disabled = IS_UT;
        GetElement('leavePeriod').toggleAttribute('required', !IS_UT);
        GetElement('leaveHours').toggleAttribute('readonly', !IS_UT);
        if (!IS_UT)
        {
            GetElement('leaveHours').value = GetElement('leavePeriod').value === 'WHOLE' ? 8 : 4;
        }
    }
    function OpenEditor(row = null, date = TODAY)
    {
        STATE.editing = row;
        GetElement('leaveForm').reset();
        ErrorAt('leaveFormError');
        GetElement('leaveForm').elements.namedItem('log_id').value = row?.log_id || '';
        GetElement('leaveForm').elements.namedItem('version').value = row?.version || '';
        for (const FIELD of ['date_from', 'date_to', 'leave_type', 'leave_period', 'duration_hours', 'remarks'])
        {
            if (row)
            {
                GetElement('leaveForm').elements.namedItem(FIELD).value = row[FIELD] ?? '';
            }
        }
        if (!row)
        {
            GetElement('leaveDate').value = date;
            GetElement('leaveDateTo').value = date;
        }
        const IS_SUBMITTED = row?.status === 'Submitted';
        GetElement('leaveEditorTitle').textContent = row ? 'Edit Leave Application' : 'Apply for Leave';
        GetElement('leaveEditorHint').textContent = IS_SUBMITTED ? 'Changes remain submitted. Your section approver must review the latest request.' : 'Your section’s authorized approver will review this request.';
        GetElement('leaveSaveDraft').hidden = IS_SUBMITTED;
        GetElement('leaveSubmit').textContent = IS_SUBMITTED ? 'Save Changes' : 'Submit Leave';
        SyncType();
        GetElement('leaveDateTo').min = GetElement('leaveDate').value;
        GetElement('leaveEditor').showModal();
    }
    async function Save(status)
    {
        if (STATE.isBusy || !GetElement('leaveDate').reportValidity() || (status === 'Submitted' && !GetElement('leaveForm').reportValidity()))
        {
            return;
        }
        ErrorAt('leaveFormError');
        Busy(true);
        try
        {
            const BODY =
            {
                ...Object.fromEntries(new FormData(GetElement('leaveForm'))), status
            };
            await Api('save_leave', BODY);
            GetElement('leaveEditor').close();
            GetElement('leaveMonth').value = BODY.date_from.slice(0, 7);
            STATE.day = BODY.date_from;
            STATE.calendarMonth = BODY.date_from.slice(0, 7);
            AT.toast(status === 'Draft' ? 'Leave saved as draft.' : 'Leave submitted for section approval.');
            await Load();
        }
        catch (error)
        {
            ErrorAt('leaveFormError', error.message);
        }
        finally
        {
            Busy(false);
        }
    }
    async function Detail(id)
    {
        try
        {
            const ROW = await Api('get_leave', null,
            {
                'log_id': id
            });
            STATE.detail = ROW;
            ErrorAt('leaveDetailError');
            const FIELDS = [['Employee', ROW.employee_name], ['Section', ROW.unit_name || 'Unassigned'], ['Date From', ROW.date_from], ['Date To', ROW.date_to], ['Working days', ROW.working_days], ['Leave', Label(ROW)], ['Total hours', Hours(ROW.total_hours)], ['Hours per working day', Hours(ROW.duration_hours)], ['Status', Status(ROW.status)]];
            if ('remarks' in ROW)
            {
                FIELDS.push(['Reason / Remarks', ROW.remarks || '—'], ['Review comment', ROW.review_comment || '—'], ['Reviewed by', ROW.reviewer_name || '—']);
            }
            GetElement('leaveDetailFields').innerHTML = FIELDS.map(([label, value]) => `<dt>${ESC(label)}</dt><dd>${ESC(value)}</dd>`).join('');
            const IS_CAN_REVIEW = IS_APPROVALS && ROW.can_review;
            GetElement('leaveReviewCommentRow').toggleAttribute('hidden', !IS_CAN_REVIEW);
            GetElement('leaveReviewComment').value = '';
            GetElement('leaveDetailActions').innerHTML = '<button type="button" class="btn" data-leave-close="leaveDetail">Close</button>' + (!IS_APPROVALS && ROW.can_delete ? '<button type="button" class="btn btn-danger" id="leaveDelete">Delete</button>' : '') + (!IS_APPROVALS && ROW.can_edit ? '<button type="button" class="btn btn-primary" id="leaveEdit">Edit</button>' : '') + (!IS_APPROVALS && ROW.can_review ? `<a class="btn" href="${ESC(ROOT.dataset.approvals)}&log_id=${ROW.log_id}">Open in Approvals</a>` : '') + (IS_CAN_REVIEW ? '<button type="button" class="btn" id="leaveReturn">' + (ROW.status === 'Reviewed' ? 'Return / Reopen' : 'Return') + '</button>' + (ROW.status === 'Submitted' ? '<button type="button" class="btn btn-primary" id="leaveApprove">Approve Leave</button>' : '') : '');
            GetElement('leaveDetail').showModal();
        }
        catch (error)
        {
            ErrorAt('leaveError', error.message);
        }
    }
    async function Decide(decision)
    {
        if (STATE.isBusy)
        {
            return;
        }
        const ROW = STATE.detail;
        const COMMENT = GetElement('leaveReviewComment').value.trim();
        if (decision === 'Returned' && !COMMENT)
        {
            ErrorAt('leaveDetailError', 'Enter a comment before returning or reopening leave.');
            return;
        }
        Busy(true);
        try
        {
            if (!await AT.confirmAction(`${ROW.employee_name} · ${ROW.date_from} to ${ROW.date_to} · ${Hours(ROW.total_hours)} hours`, decision === 'Reviewed' ? 'Approve leave?' : 'Return leave?', decision === 'Reviewed' ? 'Approve Leave' : 'Return Leave'))
            {
                return;
            }
            await Api('review_leave',
            {
                'log_id': ROW.log_id, version: ROW.version, decision, 'review_comment': COMMENT
            });
            GetElement('leaveDetail').close();
            AT.toast(decision === 'Reviewed' ? 'Leave approved.' : 'Leave returned for correction.');
            await Load();
        }
        catch (error)
        {
            ErrorAt('leaveDetailError', error.message);
        }
        finally
        {
            Busy(false);
        }
    }
    async function Delete()
    {
        if (STATE.isBusy)
        {
            return;
        }
        Busy(true);
        try
        {
            if (!await AT.confirmAction('This removes your draft or returned request.', 'Delete leave application?', 'Delete'))
            {
                return;
            }
            await Api('delete_leave',
            {
                'log_id': STATE.detail.log_id, version: STATE.detail.version
            });
            GetElement('leaveDetail').close();
            AT.toast('Leave application deleted.');
            await Load();
        }
        catch (error)
        {
            ErrorAt('leaveDetailError', error.message);
        }
        finally
        {
            Busy(false);
        }
    }
    function MoveMonth(delta)
    {
        const DATE = new Date(GetElement('leaveMonth').value + '-01T12:00:00');
        DATE.setMonth(DATE.getMonth() + delta);
        if (DATE.getFullYear() < 1900 || DATE.getFullYear() > 2100)
        {
            return;
        }
        GetElement('leaveMonth').value = `${DATE.getFullYear()}-${String(DATE.getMonth() + 1).padStart(2, '0')}`;
        STATE.minePage = 1;
        Load();
    }
    document.addEventListener('click', event =>
    {
        const BUTTON = event.target.closest('button');
        if (!BUTTON || STATE.isBusy)
        {
            return;
        }
        if (BUTTON.dataset.leaveClose)
        {
            GetElement(BUTTON.dataset.leaveClose).close();
        }
        if (BUTTON.dataset.leaveView)
        {
            Detail(BUTTON.dataset.leaveView);
        }
        if (BUTTON.dataset.leaveDay)
        {
            OpenDay(BUTTON.dataset.leaveDay, !!BUTTON.dataset.leaveReveal || !BUTTON.classList.contains('leave-calendar-select'));
        }
        if (BUTTON.dataset.leaveTab)
        {
            SetDayTab(BUTTON.dataset.leaveTab);
        }
        if (BUTTON.id === 'leaveDayApply')
        {
            OpenEditor(null, STATE.day);
        }
        if (BUTTON.id === 'leaveEdit')
        {
            GetElement('leaveDetail').close();
            OpenEditor(STATE.detail);
        }
        if (BUTTON.id === 'leaveApprove')
        {
            Decide('Reviewed');
        }
        if (BUTTON.id === 'leaveReturn')
        {
            Decide('Returned');
        }
        if (BUTTON.id === 'leaveDelete')
        {
            Delete();
        }
    });
    SetupCalendar();
    if (GetElement('leaveMonth'))
    {
        GetElement('leaveMonth').value = INITIAL.get('month') || TODAY.slice(0, 7);
    }
    GetElement('leaveAdd')?.addEventListener('click', () => OpenEditor());
    GetElement('leavePrevious')?.addEventListener('click', () => MoveMonth(-1));
    GetElement('leaveNext')?.addEventListener('click', () => MoveMonth(1));
    GetElement('leaveToday')?.addEventListener('click', () =>
    {
        GetElement('leaveMonth').value = TODAY.slice(0, 7);
        STATE.day = TODAY;
        STATE.minePage = 1;
        Load();
    });
    GetElement('leaveFilters')?.addEventListener('submit', event =>
    {
        event.preventDefault();
        STATE.minePage = 1;
        Load();
    });
    for (const [PREFIX, KEY] of [['leaveMine', 'minePage'], ['leaveReview', 'reviewPage']])
    {
        for (const [SUFFIX, DELTA] of [['Previous', -1], ['Next', 1]])
        {
            GetElement(PREFIX + SUFFIX)?.addEventListener('click', () =>
            {
                STATE[KEY] += DELTA;
                Load();
            });
        }
    }
    GetElement('leaveType')?.addEventListener('change', () =>
    {
        GetElement('leaveHours').value = '';
        SyncType();
    });
    GetElement('leavePeriod')?.addEventListener('change', SyncType);
    GetElement('leaveDate')?.addEventListener('change', () =>
    {
        if (GetElement('leaveDateTo').value < GetElement('leaveDate').value)
        {
            GetElement('leaveDateTo').value = GetElement('leaveDate').value;
        }
        GetElement('leaveDateTo').min = GetElement('leaveDate').value;
    });
    GetElement('leaveSaveDraft')?.addEventListener('click', () => Save('Draft'));
    GetElement('leaveForm')?.addEventListener('submit', event =>
    {
        event.preventDefault();
        Save('Submitted');
    });
    for (const ID of ['leaveEditor', 'leaveDetail'])
    {
        GetElement(ID)?.addEventListener('cancel', event =>
        {
            if (STATE.isBusy)
            {
                event.preventDefault();
            }
        });
    }
    document.addEventListener('keydown', event =>
    {
        const TAB = event.target.closest('[data-leave-tab]');
        if (TAB && ['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key))
        {
            event.preventDefault();
            SetDayTab(event.key === 'Home' ? 'leave' : event.key === 'End' ? 'birthday' : STATE.dayTab === 'leave' ? 'birthday' : 'leave', true);
        }
        const DAY = event.target.closest('.leave-calendar-select');
        if (!DAY || !STATE.data || STATE.isBusy)
        {
            return;
        }
        const DATE = new Date(DAY.dataset.leaveDay + 'T12:00:00');
        const DELTA = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7, Home: -DATE.getDay(), End: 6 - DATE.getDay() }[event.key];
        if (DELTA === undefined)
        {
            return;
        }
        event.preventDefault();
        DATE.setDate(DATE.getDate() + DELTA);
        const KEY = `${DATE.getFullYear()}-${String(DATE.getMonth() + 1).padStart(2, '0')}-${String(DATE.getDate()).padStart(2, '0')}`;
        if (KEY >= STATE.data.from && KEY <= STATE.data.to)
        {
            OpenDay(KEY);
            GetElement('leaveCalendar').querySelector('.leave-calendar-select[aria-pressed="true"]').focus();
        }
    });
    if (IS_APPROVALS)
    {
        GetElement('leaveRefresh').addEventListener('click', Load);
        GetElement('leaveBatchApprove')?.addEventListener('click', ApproveBatch);
        GetElement('leaveBatchClear')?.addEventListener('click', () =>
        {
            if (!STATE.isBusy && !STATE.isLoading)
            {
                STATE.selected.clear();
                UpdateBatchControls();
            }
        });
        GetElement('leaveSelectAll')?.addEventListener('change', event =>
        {
            if (!STATE.isBusy && !STATE.isLoading)
            {
                STATE.selected = event.target.checked ? new Set(STATE.data.pending.rows.map(row => String(row.log_id))) : new Set();
                UpdateBatchControls();
            }
        });
        GetElement('leaveReviewRows').addEventListener('change', event =>
        {
            const CHECK = event.target.closest('[data-leave-select]');
            if (CHECK && !STATE.isBusy && !STATE.isLoading)
            {
                if (CHECK.checked)
                {
                    STATE.selected.add(CHECK.dataset.leaveSelect);
                }
                else
                {
                    STATE.selected.delete(CHECK.dataset.leaveSelect);
                }
                UpdateBatchControls();
            }
        });
    }
    Load().then(() =>
    {
        if (INITIAL.has('log_id'))
        {
            Detail(INITIAL.get('log_id'));
        }
    });
})();
