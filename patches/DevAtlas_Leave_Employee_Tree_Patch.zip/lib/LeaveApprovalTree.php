<?php

/**
 * Filename: LeaveApprovalTree.php
 * Purpose: Group pending leave applications by employee without splitting their requests across pages.
 * Developer: DevAtlas maintainers
 * Date: 2026-11-06
 * Recent updates: Reuse section review scope and count complete applications by leave type.
 */

use CodeIgniter\Database\BaseConnection;

require_once __DIR__.'/LeaveRequests.php';

final class LeaveApprovalTree
{
    public static function Page(BaseConnection $db, int $actor, array $data): array
    {
        Permissions::Require('leaves', 'review');
        $profile = LeaveRequests::Profile($db, $actor);
        $pending = ['rows' => [],'employees' => [],'total' => 0,'total_requests' => 0,'page' => 1,'pages' => 1];
        if (empty($profile['unit_id']))
        {
            return ['pending' => $pending,'leave_types' => DailyLogs::LEAVES];
        }
        $params = [(int)$profile['unit_id']];
        $where = " WHERE l.entry_kind='leave' AND l.status='Submitted' AND u.unit_id=?";
        if (!LeaveRequests::IsSectionHead($db, $actor))
        {
            $where .= ' AND u.user_id<>?';
            $params[] = $actor;
        }
        $from = ' FROM daily_logs l JOIN leave_applications a ON a.request_id=l.leave_request_id
            JOIN users u ON u.user_id=l.user_id LEFT JOIN org_units un ON un.unit_id=u.unit_id';
        $totals = $db->query('SELECT COUNT(DISTINCT u.user_id) employees,COUNT(DISTINCT a.request_id) requests'.$from.$where, $params)->getUnbufferedRow('array');
        $pending['total'] = (int)$totals['employees'];
        $pending['total_requests'] = (int)$totals['requests'];
        $pending['pages'] = max(1, (int)ceil($pending['total'] / 10));
        $pending['page'] = min($pending['pages'], max(1, (int)($data['review_page'] ?? 1)));
        $sql = "SELECT u.user_id,u.employee_id,CONCAT_WS(' ',u.first_name,u.middle_name,u.last_name) employee_name,un.unit_name".$from.$where.
            ' GROUP BY u.user_id,un.unit_name ORDER BY LOWER(u.last_name),LOWER(u.first_name),u.user_id LIMIT 10 OFFSET '.(($pending['page'] - 1) * 10);
        $pending['employees'] = $db->query($sql, $params)->getResultArray();
        if ($pending['employees'])
        {
            $ids = array_column($pending['employees'], 'user_id');
            $sql = "SELECT MIN(l.log_id) log_id,MIN(a.version) version,u.user_id,a.date_from,a.date_to,
                MIN(l.leave_type) leave_type,MIN(l.leave_period) leave_period,SUM(l.duration_hours) duration_hours,
                COUNT(*) working_days,MIN(l.status) status,CONCAT_WS(' ',u.first_name,u.middle_name,u.last_name) employee_name".$from.$where.
                ' AND u.user_id IN('.implode(',', array_fill(0, count($ids), '?')).')
                GROUP BY a.request_id,u.user_id ORDER BY LOWER(u.last_name),LOWER(u.first_name),u.user_id,a.date_from,a.request_id';
            $pending['rows'] = $db->query($sql, array_merge($params, $ids))->getResultArray();
        }
        return ['pending' => $pending,'leave_types' => DailyLogs::LEAVES];
    }
}
