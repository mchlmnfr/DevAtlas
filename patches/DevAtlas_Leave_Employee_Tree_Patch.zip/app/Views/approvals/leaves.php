<?php
/**
 * Filename: leaves.php
 * Purpose: Render the Approvals workspace.
 * Developer: DevAtlas maintainers
 * Date: 2026-10-29
 * Recent updates: Group pending leave applications under expandable employee summaries.
 */
?>
<?= view('layouts/header', get_defined_vars()) ?>

<div
    class="ws-workspace"
    id="leaveApprovalsApp"
    data-api="<?= APP_BASE_URL ?>/modules/leaves/api.php"
    data-approvals="<?= APP_BASE_URL ?>/modules/approvals/index.php?tab=leaves"
>
    <section class="ws-hero">
        <div>
            <div class="ws-eyebrow">TEAM MONITORING</div>
            <h2>Approvals</h2>
            <p>Review daily work logs and leave applications in their own queues.</p>
        </div>
    </section>

    <?php echo view('partials/approval_tabs', get_defined_vars());
 ?>
    <div
        class="ws-error"
        id="leaveError"
        role="alert"
        tabindex="-1"
        hidden
    ></div>
    <section class="ws-card">
        <div class="ws-card-heading">
            <div>
                <h3>Leave applications</h3>
                <p>Pending applications in your own section, grouped by employee. Counts show applications, including multi-day requests as one application. Only Section Heads may approve their own leave.</p>
            </div><button
                type="button"
                class="btn"
                id="leaveRefresh"
            >Refresh</button>
        </div>
        <div class="leave-batch-toolbar">
            <div class="leave-tree-selection">
                <label><input type="checkbox" id="leaveSelectAll" disabled> <span id="leaveSelectLabel">Select applications on this page</span></label>
                <p id="leaveBatchCount" role="status" aria-live="polite">0 selected · Maximum 25 applications per batch.</p>
            </div>
            <div class="ws-actions">
                <button type="button" class="btn btn-sm" id="leaveBatchClear" disabled>Clear selection</button>
                <button type="button" class="btn btn-primary" id="leaveBatchApprove" disabled><?= UiIcon('check') ?> Approve selected</button>
            </div>
        </div>
        <div class="leave-tree-tools">
            <p>Expand an employee to see their applications. Type badges count pending applications.</p>
            <div class="ws-actions">
                <button type="button" class="btn btn-sm" id="leaveTreeExpandAll">Expand all</button>
                <button type="button" class="btn btn-sm" id="leaveTreeCollapseAll">Collapse all</button>
            </div>
        </div>
        <div id="leaveReviewRows" class="leave-approval-tree" aria-busy="true"></div>
        <div class="ws-pagination"><span id="leaveReviewCount" role="status"></span>
            <div class="ws-actions"><button
                    type="button"
                    class="btn btn-sm"
                    id="leaveReviewPrevious"
                >Previous</button><button
                    type="button"
                    class="btn btn-sm"
                    id="leaveReviewNext"
                >Next</button></div>
        </div>
    </section>
</div>

<?php echo view('partials/leave_detail_dialog', get_defined_vars());
 ?>

<?php echo view('layouts/footer', get_defined_vars());
 ?>

