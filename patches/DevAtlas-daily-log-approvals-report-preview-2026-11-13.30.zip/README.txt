DevAtlas: daily-log approvals, report preview and work-date policy
Release 2026-11-13.30

Apply over the existing DevAtlas workspace experience (release 29).

Installation:
1. Back up the eight matching files in your project.
2. Copy this archive's lib, app, assets and docs folders into C:\wamp64\www\AnalystToolkit, merging folders and replacing the eight matching files.
3. Reopen DevAtlas and press Ctrl+F5. Restart Apache through WAMP if it continues to use cached PHP code.

No database migration or SQL update is required.

Affected application files:
- lib/DailyLogs.php
- lib/WeeklyLogReview.php
- lib/DailyLogReports.php
- app/Views/reports/index.php
- assets/js/reports.js
- assets/css/reports.css
- assets/js/experience-forms.js
- docs/releases.json

Behavior:
- Adding or correcting pending daily work preserves earlier approved entries and their reviewer, timestamps, comments and version. The week appears in the pending queue when new work requires review, while earlier entries remain Approved.
- Approving or returning a pending week applies to its submitted entries. Explicitly returning a fully approved week remains available to reopen it for corrections.
- Existing entries that were already reset to Submitted by the older code still require review; this patch prevents subsequent automatic resets.
- Reports now contains expandable employee reports, with daily tasks, actual activity, hours, status, remarks and review information; weekly reports show activity/classification totals and approved leave. Reports view access is sufficient to preview. Export Excel remains available only to authorized users.
- Future daily work dates are rejected for both Draft and Submitted actions, including edits and the existing batch helper. Today uses Asia/Manila, matching the system business calendar. Leave requests and report date filters retain their existing ranges.
- The installed daily-log batch/tree scripts and controllers are retained; this archive does not replace them.

Validation: 101 PostgreSQL workflow assertions, six checks using the existing batch helper, and 35 browser/API interaction checks using an isolated fixture. Report previews enforce section scope and exclude private drafts; activity text is escaped; view access does not grant export access. Syntax and release JSON checks pass.
