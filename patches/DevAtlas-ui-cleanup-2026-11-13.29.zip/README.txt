DevAtlas - controls, tables and notifications patch (2026-11-13.29)

Apply to the existing DevAtlas installation with the shared workspace experience installed (release 26 or later). This patch follows release 28 and preserves the installed Leaves calendar layout and its event handlers.

1. Back up the seven matching files in your project.
2. Extract this archive and copy its assets and docs folders into C:\wamp64\www\AnalystToolkit, replacing the seven matching files.
3. Open Leaves and press Ctrl+F5. Other users should refresh their browsers too.

Affected application files:
- assets/js/app.js
- assets/js/ui-motion.js
- assets/js/experience-core.js
- assets/js/experience-forms.js
- assets/js/experience-tables.js
- assets/css/experience.css
- docs/releases.json

What changed:
- Leaves Month is a calendar button showing the month name and year. Open it to choose a month from a grid and a year from a dropdown, without typing a date.
- Picking a month refreshes the calendar. Existing previous/next/This month controls and saved views stay synchronized. Explicit month links take priority over saved filters. Calendar arrows are excluded from table pagination restoration so returning to Leaves does not jump to another month.
- Active filter summaries sit beneath their filter controls, using a quiet outline style. Pages with separate filter panels keep the summary inside the title's View options menu.
- Keyboard navigation, Escape, outside-click dismissal, month limits, disabled/read-only states and mobile sizing are supported.
- Removed generated Expand editor and Copy buttons from text areas and SweetAlert notifications.
- Removed changed-row flashes and row entry fades so repeated-date logs stay stable during table refreshes. Other page and sidebar transitions remain available.
- Notifications and informational popups close after four seconds, or six seconds for errors, with no notification buttons. Hovering does not stop their timer. Approval/delete/other action confirmations retain their deliberate choice controls.

What's New: 2026-11-13.29.
No database migration. No replacement of assets/js/leaves.js, assets/css/leaves.css or the Leaves PHP view is required.

Validation: 48 browser interaction checks; shared UI smoke check across 22 modules; existing calendar alignment checks including 144 month/layout cases. The browser fixture uses sample data and is not your WAMP installation.

GitHub download: open this ZIP's page in the private repository while signed in, then choose Download raw. Download this patch ZIP, rather than the repository's Code > Download ZIP.
