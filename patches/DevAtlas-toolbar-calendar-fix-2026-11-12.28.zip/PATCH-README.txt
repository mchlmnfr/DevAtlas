DevAtlas toolbar cleanup and calendar alignment — 2026-11-12.28

Requires workspace experience update 2026-11-12.26 (PR14).
Includes the compact toolbar change from 2026-11-12.27.

The large toolbar is replaced by a small three-dot View options menu beside the
page title. The idle status row is removed. Useful controls remain in the menu.

The leave calendar now uses Sunday-to-Saturday date boundaries and aligns cells
by their actual dates. November 13, 2026 appears under Friday. Existing leave
previews, selected-day controls and event handlers are retained. Business leave
calculations and approval rules are preserved.

Back up and replace these FOUR files in the project root, preserving folders:
  assets/js/experience-core.js
  assets/css/experience.css
  lib/LeaveRequests.php
  docs/releases.json

Then restart Apache through WAMP and press Ctrl+F5 in DevAtlas.
No database migration is required. Do not use the earlier version 26 installer
for this four-file update. What's New: 2026-11-12.28.
