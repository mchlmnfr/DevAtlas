<?php

/**
 * Filename: DailyLogBatch.php
 * Purpose: Save multiple work activities for one date as one atomic submission.
 * Developer: DevAtlas maintainers
 * Date: 2026-11-05
 * Recent updates: Reuse daily-log validation, permissions and weekly approval rules.
 */

use CodeIgniter\Database\BaseConnection;

require_once __DIR__ . '/DailyLogs.php';

final class DailyLogBatch
{
    public const MAX_ENTRIES = 50;

    public static function Save(BaseConnection $db, int $actor, array $data): array
    {
        Permissions::Require('dailylogs', 'create');
        if (!empty($data['log_id']) || !empty($data['version']))
        {
            throw new InvalidArgumentException('Use the individual editor to update an existing log.');
        }
        $date = DailyLogs::Date($data['activity_date'] ?? null);
        $status = $data['status'] ?? 'Draft';
        if (!in_array($status, ['Draft', 'Submitted'], true))
        {
            throw new InvalidArgumentException('Choose Draft or Submitted for the new daily logs.');
        }
        $entries = $data['entries'] ?? null;
        if (!is_array($entries) || !array_is_list($entries) || !$entries || count($entries) > self::MAX_ENTRIES)
        {
            throw new InvalidArgumentException('Add between 1 and ' . self::MAX_ENTRIES . ' work activities.');
        }
        $allowed = ['classification', 'activity_type', 'planned_task', 'actual_activity', 'duration_hours', 'remarks'];
        $rows = [];
        foreach ($entries as $index => $entry)
        {
            if (!is_array($entry) || array_diff(array_keys($entry), $allowed))
            {
                throw new InvalidArgumentException('Activity ' . ($index + 1) . ': use only work activity fields.');
            }
            try
            {
                $rows[] = DailyLogs::Normalize(array_merge($entry, [
                    'activity_date' => $date, 'entry_kind' => 'activity', 'status' => $status,
                ]));
            }
            catch (InvalidArgumentException $error)
            {
                throw new InvalidArgumentException('Activity ' . ($index + 1) . ': ' . $error->getMessage(), 0, $error);
            }
        }
        $db->transBegin();
        try
        {
            $ids = [];
            foreach ($rows as $index => $row)
            {
                try
                {
                    $ids[] = DailyLogs::Save($db, $actor, $row);
                }
                catch (InvalidArgumentException $error)
                {
                    throw new InvalidArgumentException('Activity ' . ($index + 1) . ': ' . $error->getMessage(), 0, $error);
                }
            }
            $db->transCommit();
            return $ids;
        }
        catch (Throwable $error)
        {
            if (Database::InTransaction($db))
            {
                $db->transRollback();
            }
            throw $error;
        }
    }
}
