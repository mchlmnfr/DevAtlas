DevAtlas workspace experience 2026-11-12.26 — affected files only

Requires DevAtlas main through PR #13. Extract this ZIP to a separate folder. Open PowerShell in that folder and run:

  .\bin\Update-WorkspaceExperience.ps1 -ProjectPath 'C:\wamp64\www\AnalystToolkit'

If PHP is not found, append -PhpPath with the full path to WAMP php.exe.
The script validates file checksums, checks PHP syntax, backs up replaced files,
copies the affected files, runs the two dated workspace migrations, attempts to
restart Apache and opens the Dashboard. Use WAMP to restart Apache if needed.

Manual installation: back up the affected files; copy the files with their folder
structure into your existing project; run php bin/install-workspace-experience.php;
restart Apache, open Dashboard and press Ctrl+F5.

Do not execute database/schema.sql against an existing database. It is included
for fresh installations. The dated installer preserves existing preferences.
See docs/workspace-experience.md for features, limits and installation details.
What's New: docs/releases.json, release 2026-11-12.26.
