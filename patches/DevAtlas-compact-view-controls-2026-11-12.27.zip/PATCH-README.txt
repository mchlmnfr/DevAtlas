DevAtlas: compact workspace controls — 2026-11-12.27

Requires the workspace experience update 2026-11-12.26 (PR14).

This patch replaces the large toolbar with a small three-dot View options menu
beside the page title. Refresh, Appearance, Shortcuts, saved views and page size
are available in that menu. Undo appears after a display change. The idle data
status row is removed; useful loading, error and update notices remain.

Back up these three files, then copy them into your existing project while
preserving the folder structure:
  assets/js/experience-core.js
  assets/css/experience.css
  docs/releases.json

Open DevAtlas and press Ctrl+F5. No database migration is needed for this patch.
What's New: release 2026-11-12.27.
